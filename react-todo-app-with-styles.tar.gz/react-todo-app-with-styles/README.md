# todo app

## Prerequisite to working in React. You should know,
1. ES6 Classes
2. Arrow Function
3. Let & Const

## Todo App components
1. TodoApp
2. Title
3. AddTodo
4. TodoList
5. Todo

## Steps to run
1. Open your terminal, navigate to the root location and type `npm install`
2. Start webpack dev server by typing `npm run webpack-dev-server`

## Stateful vs Stateless Components 
## Stateful Container Components Vs Stateless Presentation Components