/* Write a Program to Flatten a given n-dimensional array */

const flatten = (multiDimArray) => {
	// Write your code here
	if(Array.isArray(multiDimArray)){

		const fullflatten = (array, depth, result) => {
			let index = -1;
			let length = array.length;

			result || (result = []);
			while(++index <  length){
				let value = array[index];


				if(depth > 0 && Array.isArray(value)){
					if(depth > 1){
						fullflatten(value, depth - 1, result);
					}else{
						result.push(value);
					}
				}else{
					result.push(value);
				}
			}

			return result;
		}



		const length = multiDimArray? multiDimArray.length:0;
		return length ? fullflatten(multiDimArray, Infinity) : [];
	}else{
		return null;
	}



};

/* For example,
INPUT - flatten([1, [2, 3], [[4], [5]])
OUTPUT - [ 1, 2, 3, 4, 5 ]

*/
const myArray = flatten('invalid value');
module.exports = flatten;
