/* Write a program to build a `Pyramid of stars` of given height */

const buildPyramid = (a) => {

    let result = '';

    if(a !== null && !(isNaN(a))){



        let i = 0;
        let j = 0;
        //var k = (2*a) -1;
        let k = a;

        for(i = 0; i < a; i=i+1){

            for(j = 0; j < k; j=j+1){
                //process.stdout.write(' ');
                result = result + ' ';
            }
            k = k-1;
            for(j = 0; j <= i; j=j+1){
                //console.log('* ');
                //process.stdout.write('* ');
                result = result + '* ';
            }
            //console.log('\n');
            result = result + ' '+ '\n';
            //console.log('Result :' +result);

        }
        return result;
    }else{
        return result;
    }
};

/* For example,
INPUT - buildPyramid(6)
OUTPUT -
     *
    * *
   * * *
  * * * *
 * * * * *
* * * * * *

*/
const ouputval = buildPyramid(5);
module.exports = buildPyramid;
