// Create a list of fruits with their properties (name, color, pricePerKg)
// and convert it into a format so that for a given fruit name
// retrieval of its color and pricePerKg value is fast


const fruits = [
    {
        "name" : "Apple",
        "color" : "red",
        "priceperkg" : 150
    },
    {
        "name" : "Mango",
        "color" : "green",
        "priceperkg" : 100
    },
    {
        "name" : "Banana",
        "color" : "yellow",
        "priceperkg" : 80
    },
    {
        "name" : "Grapes",
        "color" : "black",
        "priceperkg" : 70
    }
]

const pickdetails = (itemName) => {

    //console.log(itemName);
    const length = fruits? fruits.length : 0;
    //console.log(length);
    const details = [];

    fruits.forEach(fruit =>{
        if(fruit.name === itemName){
            details.push(fruit.color);
            details.push(fruit.priceperkg);
        }
    });
    return details;
}

const fruitDetails = pickdetails('Grapes');
