/* Write a Program to convert an array of objects to an object
	based on a given key */


	const convert = (inputArray, keyField) => {

		let result = null;
		// Write your code here
		if(Array.isArray(inputArray)){
			 result =  inputArray.reduce((obj, item) =>
			{
				obj[item[keyField]] = item
				return obj
			}, {})
	
			return result;
		}else{
			return result;
		}
	
	
	};

/* For example,
INPUT - convert([{id: 1, value: 'abc'}, {id: 2, value: 'xyz'}], 'id')
OUTPUT - {
			'1': {id: 1, value: 'abc'},
			'2': {id: 2, value: 'xyz'}
		 }


*/
const output = convert([{name: 'Arjun', age: 26, desig: 'Manager'},
{name: 'Praba', age: 27, desig: 'Chairman'}], 'desig');
module.exports = convert;
