// Write a program to display one result card of 100 students
// with their name and percentage
// Out of 100 students, 50 has subjects - Grammer and Accounts
// and other 50 has subjects -  Grammer and Physics

// Hint : You need to calculate percentage of 100 students having different set of subjects.
//        You can assume their scores on their respective subjects.



const getScoreCard=() => {

    const studScoreCard =  [];

    for(let i=0; i<100;i=i+1) {
        let temp = {};
        temp.name = "stud"+(i+1);
        temp.subj1 = "Grammar";

        temp.subj1Score = 70;
        if (i % 2 === 0) {
            temp.subj2 = "Physics";
            temp.subj2Score = 80;
        } else {
            temp.subj2 = "Accounts";
            temp.subj2Score = 80;
        }
        temp.percentage = 0;

        studScoreCard[i] = temp;
    }

    /*let result = studScoreCard.reduce((initial, stud) => {
        initial[stud.name] = (stud.subj1Score + stud.subj2Score) /2; return initial;}, {});*/

    /*let result1 = studScoreCard.map((stud) => {
        return "Name : " + stud.name + " Precentage : " +
        ((stud.subj1Score + stud.subj2Score) /200 * 100);}); */

    studScoreCard.forEach(student => {
        let percent = (student.subj1Score + student.subj2Score)/200 * 100;
        student.percentage = percent;
    });

    //console.log(studScoreCard);
    const tbody = document.getElementsByTagName('tbody')[0];

    let tbodyInnerHtml = '';
    studScoreCard.forEach(student => {

        tbodyInnerHtml = tbodyInnerHtml +
        `<tr>
            <td>${student.name}</td>
            <td>${student.subj1}</td>
            <td>${student.subj1Score}</td>
            <td>${student.subj2}</td>
            <td>${student.subj2Score}</td>
            <td>${student.percentage}</td>
        </tr>`

    });
    tbody.innerHTML = tbodyInnerHtml;

}
