let JSONData = {movies: [], favourites: []};

const RenderJSONData = type => (movie, index) => `<li class="card mb-3">
                <img class="card-img-top" src="${movie.posterPath}" alt="Card image">
                <div class="card-body">
                    <h4 class="card-title">${movie.title}</h4>
                    <p class="card-text">${movie.overview}</p>
                    ${type.includes('movie') ?
                        `<button data-id="${movie.id}" data-index="${index}"
                            class="add-to-favourites btn btn-primary w-100">Add to Favourites</button>` : ''}
                </div>
                </li>`;
 
const RenderJSONMovieData = RenderJSONData('movie');

const RenderJSONFavouriteData = RenderJSONData('favourite');

const getElement = (id, arr) => arr.find(movie => movie.id === id);

function addFavourite(id) {

                let movieId = Number(id);

                if(getElement(movieId, JSONData.favourites)) {
                                alert('Movie is already added to Favourites');
                                return Promise.reject({message: 'Movie is already added to favourites'});

                }

                const movie = getElement(movieId, JSONData.movies);

                const favEle = document.getElementById('favouritesList');

                favEle.innerHTML = favEle.innerHTML + RenderJSONFavouriteData(movie);

                return fetch('http://localhost:3000/favourites', {

                                body: JSON.stringify(movie),

                                headers: {

                                                'content-type': 'application/json'

                                },

                                method: 'POST'

                })

                .then(() => JSONData.favourites.push(movie) && JSONData.favourites)

                .catch(err => Promise.resolve(err));

}

const addFavHandler = event => addFavourite(event.target.dataset.id);

function getMovies() {

                return fetch('http://localhost:3000/movies')

                .then(res => res.json())

                .then(data => {

                                JSONData.movies = data;

                                document.getElementById('moviesList').innerHTML = data.map(RenderJSONMovieData).join('');

                                Array.from(document.getElementsByClassName('add-to-favourites'))

                                .map(ele => {ele.onclick = addFavHandler;});

                                return data;

                })

                .catch(err => Promise.resolve(err));

}

 

function getFavourites() {

                return fetch('http://localhost:3000/favourites')

                .then(res => res.json())

                .then(data => {

                                JSONData.favourites = data;

                                document.getElementById('favouritesList').innerHTML = data.map(RenderJSONFavouriteData).join('');

                                return data;

                })

                .catch(err => Promise.resolve(err));

}

 
 module.exports = {
                 getMovies,
               getFavourites,
                addFavourite

 };

 

// You will get error - Uncaught ReferenceError: module is not defined

// while running this script on browser which you shall ignore

// as this is required for testing purposes and shall not hinder

// it's normal execution​
















