import React, { Fragment } from 'react';
import { MDBCarousel, MDBCarouselInner, MDBCarouselItem, MDBView, MDBMask, MDBContainer } from "mdbreact";


import takeANote from '../images/note.png';


function WelcomePage(props) {
    return (
        <Fragment>
            <MDBContainer>
            <MDBView>
                                <img className="w-100" src={takeANote} alt="First slide" />                                
                                <MDBMask overlay="black-light" />
                            </MDBView>
            </MDBContainer>
            
        </Fragment>
    );


};

export default WelcomePage;