import * as firebase from 'firebase';

const config = {
  apiKey: "AIzaSyDyCg4IA8RADwjwdGO0QcffjXVDNQoWqsc",
  authDomain: "note-app-2-b0a07.firebaseapp.com",
  databaseURL: "https://note-app-2-b0a07.firebaseio.com",
  projectId: "note-app-2-b0a07",
  storageBucket: "note-app-2-b0a07.appspot.com",
  messagingSenderId: "518902525375"
};
firebase.initializeApp(config);
  const googleAuthProvider =new firebase.auth.GoogleAuthProvider();
  
  export {firebase,googleAuthProvider};