let movieList;
function getMovies() {
	fetch('http://localhost:3000/movies').then(response =>{
		//console.log('Response'+response);
		if(response.ok){         
			return response.json();          
	}
	else if(response.status == 404){
		return Promise.reject(new Error('Invalid URL'))
	}
	else if(response.status == 401){
		return Promise.reject(new Error('UnAuthorized User...'));
	}
	else{
		return Promise.reject(new Error('Some internal error occured...'));
	}
	}).then(movieResponse =>{
		//console.log('contacts Response',contactsResponse);
			movieList = movieResponse;  
		  displayMovie(movieList);
	  }).catch(error =>{
		//  console.log('error',error);
		const errorEle = document.getElementById('error');
		errorEle.innerHTML = `<h2 style='color:red'>${error.message}</h2>`
		  
	  })
}
function displayMovie(movieList){
    
  const list =   document.getElementById('moviesList');
  const tableBodyEle = list.getElementsByTagName('tbody')[0];
  let unorderList = '';
  console.log('Movie List', movieList);
  
  movieList.forEach(movie => {
      unorderList += `
		<tr>
	  <td>${movie.id}</td>
            <td>${movie.Title}</td>
            <td>${movie.Poster_path}</td>
			<td>${movie.Year}</td>
			<td>${movie.Director}</td>
			<td><button class='btn btn-primary' onclick='addFavourite(${movie})'>AddFavourite</button></td>
            </tr>
			`

      
  });

  tableBodyEle.innerHTML = unorderList;
  
}


function getFavourites() {
	

}

function addFavourite(movies) {
	movies.preventDefault();
    //Get the data from the form
    // let id = document.getElementById('name').value;
    // let Title = document.getElementById('contactno').value;
	// let Poster_path = document.getElementById('email').value;
	// let Year =
	// let Director=

    // const contact = {
    //     name : name,
    //     contactno : contactno,
    //     email : email
    // };

    console.log(movies.id + '' + movies.Title + " "+ movies.Poster_path);
}

// module.exports = {
// 	getMovies,
// 	getFavourites,
// 	addFavourite
// };

// You will get error - Uncaught ReferenceError: module is not defined
// while running this script on browser which you shall ignore
// as this is required for testing purposes and shall not hinder
// it's normal execution


