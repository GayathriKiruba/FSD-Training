# todo-app

## Steps to run the program
1. `npm install`
2. `npm run start:babel`
3. `npm run start:live-server`

## Components used inside todo-app
1. TodoApp
2. Header
3. AddTodo
4. TodoList
5. Todo

## Exercise

Create the functionality to remove a todo from the todo list.