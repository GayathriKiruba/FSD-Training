'use strict';

var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

// An HTML attribute, <img src="./location"></img>
// Props can be thought of as argument passed to a function

// TodoApp component will have state
// this.setState(() => {});
// this.setState({});
var TodoApp = function (_React$Component) {
    _inherits(TodoApp, _React$Component);

    function TodoApp(props) {
        _classCallCheck(this, TodoApp);

        var _this = _possibleConstructorReturn(this, (TodoApp.__proto__ || Object.getPrototypeOf(TodoApp)).call(this, props));

        _this.state = {
            todos: [],
            title: 'todo-app'
        };
        _this.handleOnSubmit = _this.handleOnSubmit.bind(_this);
        return _this;
    }

    // We are not mutating the this.state.todos array.
    // State in React component should be Immutable


    _createClass(TodoApp, [{
        key: 'handleOnSubmit',
        value: function handleOnSubmit(todoValue) {
            // Go and update the state
            var newTodo = [{
                id: Math.random() * 340293842,
                value: todoValue
            }];
            this.setState(function (currState) {
                return {
                    todos: currState.todos.concat(newTodo)
                };
            });
        }
    }, {
        key: 'render',
        value: function render() {
            console.log(this.state);
            return React.createElement(
                'div',
                null,
                React.createElement(Header, { title: this.state.title }),
                React.createElement(AddTodo, { handleOnSubmit: this.handleOnSubmit }),
                React.createElement(TodoList, { todos: this.state.todos })
            );
        }
    }]);

    return TodoApp;
}(React.Component);

// Header Component

var Header = function (_React$Component2) {
    _inherits(Header, _React$Component2);

    function Header() {
        _classCallCheck(this, Header);

        return _possibleConstructorReturn(this, (Header.__proto__ || Object.getPrototypeOf(Header)).apply(this, arguments));
    }

    _createClass(Header, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'h1',
                null,
                this.props.title
            );
        }
    }]);

    return Header;
}(React.Component);

// eleements with state in HTML - input, textarea, checkboxes, dropdowns...etc.

// once we controle the state of a component, there is a big advantage?
// all state is getting tracked in 1 place, makes it so much easier to maintain the state
// single source of truth
// this.setState(() => {})
// this.setState({})


var AddTodo = function (_React$Component3) {
    _inherits(AddTodo, _React$Component3);

    function AddTodo(props) {
        _classCallCheck(this, AddTodo);

        var _this3 = _possibleConstructorReturn(this, (AddTodo.__proto__ || Object.getPrototypeOf(AddTodo)).call(this, props));

        _this3.state = {
            value: ''
        };
        _this3.handleOnSubmit = _this3.handleOnSubmit.bind(_this3);
        _this3.handleOnchange = _this3.handleOnchange.bind(_this3);
        return _this3;
    }

    _createClass(AddTodo, [{
        key: 'handleOnSubmit',
        value: function handleOnSubmit(e) {
            e.preventDefault();
            this.props.handleOnSubmit(this.state.value);
            this.state.value = '';
        }
    }, {
        key: 'handleOnchange',
        value: function handleOnchange(e) {
            this.setState({
                value: e.target.value
            });
        }
    }, {
        key: 'render',
        value: function render() {
            return React.createElement(
                'div',
                null,
                React.createElement(
                    'form',
                    { onSubmit: this.handleOnSubmit },
                    React.createElement('input', { type: 'text', value: this.state.value, onChange: this.handleOnchange }),
                    React.createElement(
                        'button',
                        { type: 'submit' },
                        'Add'
                    )
                )
            );
        }
    }]);

    return AddTodo;
}(React.Component);

var TodoList = function (_React$Component4) {
    _inherits(TodoList, _React$Component4);

    function TodoList() {
        _classCallCheck(this, TodoList);

        return _possibleConstructorReturn(this, (TodoList.__proto__ || Object.getPrototypeOf(TodoList)).apply(this, arguments));
    }

    _createClass(TodoList, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'ul',
                null,
                this.props.todos.map(function (todo) {
                    return React.createElement(Todo, { key: todo.id, todo: todo });
                })
            );
        }
    }]);

    return TodoList;
}(React.Component);

var Todo = function (_React$Component5) {
    _inherits(Todo, _React$Component5);

    function Todo() {
        _classCallCheck(this, Todo);

        return _possibleConstructorReturn(this, (Todo.__proto__ || Object.getPrototypeOf(Todo)).apply(this, arguments));
    }

    _createClass(Todo, [{
        key: 'render',
        value: function render() {
            return React.createElement(
                'li',
                null,
                this.props.todo.value,
                React.createElement(
                    'button',
                    null,
                    'Remove'
                )
            );
        }
    }]);

    return Todo;
}(React.Component);

var appRoot = document.getElementById('app');

ReactDOM.render(React.createElement(TodoApp, null), appRoot);
